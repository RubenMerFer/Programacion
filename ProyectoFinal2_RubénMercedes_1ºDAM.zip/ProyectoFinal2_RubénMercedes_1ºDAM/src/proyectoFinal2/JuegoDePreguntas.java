package proyectoFinal2;

import java.util.Scanner;
import proyectoFinal2.Partida;

public class JuegoDePreguntas implements JuegoInterfaz{

	//Atributos
	private Scanner entrada;
	private int opcion;
	boolean opcionAceptada=false;
	boolean salir=false;
	private String jugador1, jugador2, jugador3, jugador4;
	private int contVictoriasJug1=0, contVictoriasJug2=0, contVictoriasJug3=0, contVictoriasJug4=0;
	private int totalVictoriasJug1=0, totalVictoriasJug2=0, totalVictoriasJug3=0, totalVictoriasJug4=0;
	private Jugador[] jugadores;
	private int numRondas;
	
	public JuegoDePreguntas() {
		entrada=new Scanner(System.in);
	}
	
	//Implementación de los métodos de la interfaz
	
	public void iniciar() {
		
		do {
			do {
				System.out.println("");
				System.out.println("MENÚ PRINCIPAL");
				System.out.println("1. JUGAR PARTIDA");
				System.out.println("2. SALIR");
				System.out.print("INGRESE UNA OPCIÓN: ");
				opcion=entrada.nextInt();
				if (opcion ==1 || opcion ==2) {
					opcionAceptada=true;
				} else {
					System.out.println("OPCIÓN NO VÁLIDA, VUELVE A INTENTARLO.");
					opcionAceptada=false;
				}
			}while (!opcionAceptada);
			
			switch (opcion) {
			case 1:
				jugar();
				break;
			case 2:
				finalizar();
				System.out.println("HASTA LA PRÓXIMA");
				salir=true;
				break;
			}
		} while(!salir);
		
	}

	
	public void jugar() {
//		Jugador [] jugadores;
//		int numRondas;
		Scanner entrada = new Scanner(System.in);
		Ronda ronda = new Ronda(jugadores, numRondas);

	    for (int i = 0; i < numRondas; i++) {
	        System.out.println("Ronda " + (i + 1));
	        System.out.println("--------");
	        
	        for (int j = 0; j < jugadores.length; j++) {
	        	Jugador jugador = jugadores[j];
	            System.out.println("Turno de " + jugador.getNombre());
	            ronda.Pregunta();
	            
	            // Obtener la respuesta del jugador utilizando el objeto Scanner
	            String respuesta = entrada.nextLine();
	            
	            // Validar y procesar la respuesta
	            
	            // Resto del código...
	        }
	    }
		
	}
	

	public void gestionJugadores() {
		
	}
	
	public void historico() {
		// TODO Auto-generated method stub
		
	}

	
	public void ranking() {
		// TODO Auto-generated method stub
		
	}

	
	public void finalizar() {
		// TODO Auto-generated method stub
		
	}
	
	//Creamos el método jugarPartida para jugar la partida
	public static void jugarPartida(Scanner entrada) {
		boolean totalJugAceptados=false;
		boolean totalRondAceptadas=false;
		boolean cpu= false;
		String cpu1="CPU1";
		String cpu2="CPU2";
		String cpu3="CPU3";
		String cpu4="CPU4";
//		int numJugadores=0;
//		Jugador [] jugadores= new Jugador[numJugadores];
		
			//Información para iniciar la partida
		System.out.print("INGRESE EL NÚMERO DE JUGADORES (1-4): ");
		 int numJugadores= entrada.nextInt();
		 System.out.print("INGRESE EL NÚMERO DE RONDAS (3,5,10 Ó 20): ");
		 int numRondas=entrada.nextInt();
		do {
			if((numJugadores >=1 && numJugadores <=5) && (numRondas==3 || numRondas==5 || numRondas==10 || numRondas==20) ) {
				totalJugAceptados=true;
				totalRondAceptadas=true;
			} else {
//				System.out.print("INGRESE EL NÚMERO DE JUGADORES (1-4): ");
//				 int numJugadores= entrada.nextInt();
				System.out.println("ERROR, LOS JUGADORES (ENTRE 1-4) Y LAS RONDAS (ENTRE 3,5,10 Ó 20). VUELVE A INTENTARLO");
				 totalJugAceptados=false;
				 totalRondAceptadas=false;
			}
			
		}while (!totalJugAceptados && !totalRondAceptadas);
		 
		JuegoDePreguntas juego = new JuegoDePreguntas();
        juego.jugadores = new Jugador[numJugadores];
        juego.numRondas = numRondas;
		
		//Crear jugadores y asignarles un nombre
		
		for (int i=0; i<numJugadores;i++) {
			System.out.print("ESCRIBE EL NOMBRE DEL JUGADOR " + (i+1) + " :");
			String nombre=entrada.next();
			if (nombre.equalsIgnoreCase(cpu1)|| nombre.equalsIgnoreCase(cpu2) || nombre.equalsIgnoreCase(cpu3) || nombre.equalsIgnoreCase(cpu4) ) {
				juego.jugadores[i]=new Jugador(nombre,0, true );
			} else {
				juego.jugadores[i]=new Jugador(nombre,0, false );
			}
			
		}

		 // Comenzamos la partida
		juego.jugar();
		}

}
