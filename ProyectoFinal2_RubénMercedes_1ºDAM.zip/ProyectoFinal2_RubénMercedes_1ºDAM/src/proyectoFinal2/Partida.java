package proyectoFinal2;

public abstract class Partida {

	//Atributos
	private Jugador[] jugadores; /*13-05-2023, private int jugadores; lo cambié al
	solucionar el problema que me daba en JuegoDePreguntas*/ 
	private int numRondas;
	
	//Constructor
	public Partida(Jugador[] jugadores, int numRondas) {
		super();
		this.jugadores = jugadores;
		this.numRondas = numRondas;
	}

	
	//Getters y Setters
	public Jugador[] getJugadores() {
		return jugadores;
	}

	public void setJugadores(Jugador[] jugadores) {
		this.jugadores = jugadores;
	}

	public int getNumRondas() {
		return numRondas;
	}

	public void setNumRondas(int numRondas) {
		this.numRondas = numRondas;
	}
	
	//Método abstracto
	abstract public String Pregunta();
	
}
