package proyectoFinal2;

import java.util.Random;

public class Mates {
	
	//Método para generar el operador aleatorio
		private String generarOperadorAleatorio() {
			Random random= new Random();
			String [] operadores= {"+", "-", "*"};
			int indiceOperadores=random.nextInt(operadores.length);
			return " " + operadores[indiceOperadores] + " ";
			/*Con este método se elegirá aleatoriamenteun operador entre '+', '-' y '*'*/
		}
		
	// Método para generar el número aleatorio
		private int generarNumeroAleatorio(int min, int max) {
			Random random= new Random();
			return random.nextInt(max-min+1) + min;
			/*Con este método se generará un número aleatorio dentro de un rango especificado*/
		}
		
	//Método para generar la pregunta aleatoria
		public String generaPregunta() {
			Random random= new Random(); /*Utilizamos el objeto Random para generar los números y operadores aleatorios*/
			int numOperandos= random.nextInt(5) + 4; /*Aquí generamos un número aleatorio entre 0 y 4 (ambos incluidos) usando el nextInt(5) y luego
			para obtener un número aleatorio de 4 a 8 simplemente le sumamos 4 al resultado obtenido del nextInt(5)*/
			
			StringBuilder pregunta= new StringBuilder(); /*Esta línea lo que hace es crear un objeto StringBuilder llamado pregunta vacío que
			se utilizará para construir la pregunta de Mates mediante la concatenación de operandos y operadores.
			Luego con el for se irán agregando los operandos y operadores a la cadena para construir la expresión matemática.*/
			
			//Generamos la expresión matemática
			for (int i=0; i<numOperandos; i++) {
				if (i > 0) {
					pregunta.append(generarOperadorAleatorio()); //Llamamos al método generarOperadorAleatorio
				}
				pregunta.append(generarNumeroAleatorio(2,12)); //Llamamos al método generarNumeroAleatorio
			}
			return pregunta.toString();
		}

		//Método para validar la respuesta
		public boolean validarRespuesta(String respuesta) {
		    // Obtener los operandos y operadores de la pregunta generada previamente
			String pregunta=generaPregunta();
		    String[] elementos = pregunta.split("\\s+"); // Dividir la pregunta en elementos separados por espacios

		    //Validar la respuesta
		    int resultado = Integer.parseInt(elementos[0]); // El primer elemento es un número
		    
		    for (int i=1; i<elementos.length; i+=2) {
		    	String operador=elementos[i];
		        int operando = Integer.parseInt(elementos[i + 1]);
		        
		        //Realizamos la operación según el operador
		        switch (operador) {
		        case "+":
		        	resultado +=operando;
		        	break;
		        case "-":
		        	resultado -=operando;
		        	break;
		        case "*":
		        	resultado *=operando;
		        	break;
		        	default:
		        		//El operador no es válido
		        		return false;
		        }
		    }
		    
		    //Convertir la respuesta proporcionada a entero
		    int respuestaInt;
		    try {
		        respuestaInt = Integer.parseInt(respuesta);
		    } catch (NumberFormatException e) {
		        return false; // La respuesta no es un número válido
		    }
		    
		    //Comparar la respuesta con el resultado calculado
		    return respuestaInt==resultado;
		    
//			return false;
		}
		


}
