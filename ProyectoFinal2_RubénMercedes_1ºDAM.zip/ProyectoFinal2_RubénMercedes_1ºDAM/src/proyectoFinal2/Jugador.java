package proyectoFinal2;

public class Jugador {

	//Atributos
	private String nombre;
	private int puntuacion;
	private boolean cpu;
	
	//Constructor
	public Jugador(String nombre, int puntuacion, boolean cpu) {
		super();
		this.nombre = nombre;
		this.puntuacion = puntuacion;
//		this.cpu = false;
	}

	
	// Getters y Setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public boolean getCpu() {
		return cpu;
	}


	public void setCpu(boolean cpu) {
		this.cpu = cpu;
	}

	
	public int getPuntuacion() {
		return puntuacion;
	}

	public void setPuntuacion(int puntuacion) {
		this.puntuacion = puntuacion;
	}
	

	
	

	
	
}

