package proyectoFinal2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Letras {
	
	
	
	//obtenemos las palabras del diccionario
	private ArrayList<String> obternerPalabrasDelDiccionario(){
		ArrayList<String> palabras= new ArrayList<>();
		try (BufferedReader br = new BufferedReader (new FileReader("diccionario.txt"))){
			/*El BufferedReader lee el contenido del fichero y FileReader abre el fichero*/
			String palabra;
			while ((palabra= br.readLine()) !=null) { /*se seguirán leyendo líneas del fichero hasta que se alcance el final del mismo.*/
				 palabras.add(palabra); /*se lee una línea del archivo utilizando br.readLine() y se asigna a la variable palabra.*/
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return palabras;
	
	}

	//generamos la pregunta
	public String generaPregunta() {
		ArrayList<String> palabras= obternerPalabrasDelDiccionario();
		Random random= new Random();
		int indice= random.nextInt(palabras.size());
		String palabra= palabras.get(indice);
		
		int longitud=palabra.length();
		int letrasOcultas= longitud / 3;
		
		StringBuilder pregunta= new StringBuilder();
		for (int i=0; i< longitud; i++) {
			if((i+1) % 3 ==0 && letrasOcultas >0) {
				pregunta.append("*");
				letrasOcultas--;
			} else {
				pregunta.append(palabra.charAt(i));
			}
		}
		return pregunta.toString();
	}
	
	//Método para validar la respuesta
	public boolean validarRespuesta(String palabra, String respuesta) {
		int longitud=palabra.length();
		
		if(respuesta.length() !=longitud) {
			return false; // La longitud de la respuesta no coincide con la longitud de la palabra
		}
		
		for (int i=0; i<longitud; i++) {
			char letraPalabra=palabra.charAt(i);
			char letraRespuesta=respuesta.charAt(i);
			
			if(letraRespuesta !='*' && letraRespuesta != letraPalabra) {
				return false; //La letra en la posición i de la respùesta no coincide con la letra de la palabra original 
			}
		}
		return true; //Todas las letras de la respuesta coinciden con las letras de la palabra original
	}

}
