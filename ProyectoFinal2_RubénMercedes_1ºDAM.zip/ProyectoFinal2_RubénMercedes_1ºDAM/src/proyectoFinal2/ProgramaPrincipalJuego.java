package proyectoFinal2;

import java.io.FileNotFoundException;

public class ProgramaPrincipalJuego {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		Alternativa_JuegoDePreguntas juego= new Alternativa_JuegoDePreguntas();
		juego.iniciar();

	}

}

