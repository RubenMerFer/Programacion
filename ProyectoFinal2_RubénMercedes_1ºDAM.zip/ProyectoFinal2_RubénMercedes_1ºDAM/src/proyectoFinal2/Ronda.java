package proyectoFinal2;

import java.util.Random;

public class Ronda extends Partida {

	int tipoPregunta= -1;
	public Ronda(Jugador[] jugadores, int numRondas) {
		super(jugadores, numRondas);
		// TODO Auto-generated constructor stub
	}

	

	
	public String Pregunta() {
		Random random=new Random();
		this.tipoPregunta = random.nextInt(3); /* Generamos un número aleatorio entre 0 y 2 para 
		definir si la pregunta es de mates, letras o inglés*/
		
		String pregunta="";
		
		if (tipoPregunta==0) { //pregunta de mates
			//generamos la pregunta
			Mates mates =new Mates();
			pregunta=mates.generaPregunta();
			System.out.print("PREGUNTA DE MATES: " + pregunta);
		} else if (tipoPregunta==1) { //pregunta de letras
			//generamos la pregunta
			Letras letras= new Letras();
			pregunta=letras.generaPregunta();
			System.out.println("PREGUNTA DE LETRAS: " + pregunta); 
		}else { //pregunta de inglés
			//generamos la pregunta
			Ingles ingles=new Ingles();
			pregunta=ingles.generaPregunta();
			System.out.println("PREGUNTA DE INGLÉS: " + pregunta);
		}
		
		return pregunta;
		
		}

	public boolean validarRespuesta(String respuesta) {
		boolean esCorrecta=false;
		
		if (tipoPregunta == 0) { // pregunta de mates
            Mates mates = new Mates();
            esCorrecta = mates.validarRespuesta(respuesta);
        } else if (tipoPregunta == 1) { // pregunta de letras
            Letras letras = new Letras();
            String pregunta = letras.generaPregunta(); // Genera la pregunta para obtener la palabra original
            esCorrecta = letras.validarRespuesta(pregunta,respuesta);
        } else { // pregunta de inglés
            Ingles ingles = new Ingles();
            String pregunta = ingles.generaPregunta(); // Genera la pregunta para obtener la palabra original
            esCorrecta = ingles.validarRespuesta(pregunta,respuesta);
        }
		
		return esCorrecta;
	}
	
}
