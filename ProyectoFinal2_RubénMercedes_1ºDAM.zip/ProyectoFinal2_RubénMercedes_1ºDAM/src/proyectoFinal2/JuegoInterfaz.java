package proyectoFinal2;

import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * El nombre de la interfaz
 * @author Black24Mamba
 *
 */
public interface JuegoInterfaz {

	/**
	 * Para iniciar el juego
	 * @throws FileNotFoundException 
	 */
	public void iniciar() throws FileNotFoundException;
	
	/**
	 * Para jugar, usamos el objeto de tipo Scanner para leer la entrada de datos
	 * @param entrada
	 */
	public void jugar();
	
	/**
	 * Aquí se almacenará una lista de todos los jugadores humanos y el Nº total de preguntas correctas
	 */
	public void ranking();
	
	/**
	 * Aquí se almacenará el historial de partidas jugadas
	 */
	public void historico();
	
	/*
	 * Para gestionar a los jugadores
	 */
	public void gestionJugadores() throws FileNotFoundException;
	
	/**
	 * Para finalizar el juego
	 */
	public void finalizar();
}
