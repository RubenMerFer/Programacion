package proyectoFinal2;

import java.util.Scanner;
import proyectoFinal2.Partida;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class JuegoDePreguntas implements JuegoInterfaz{
	
		//Atributos
		private Scanner entrada;
		private int opcion;
		boolean opcionAceptada=false;
		boolean salir=false;
		private String jugador1, jugador2, jugador3, jugador4;
		private int contVictoriasJug1=0, contVictoriasJug2=0, contVictoriasJug3=0, contVictoriasJug4=0;
		private int totalVictoriasJug1=0, totalVictoriasJug2=0, totalVictoriasJug3=0, totalVictoriasJug4=0;
		private int numJugadores=0;
		private Jugador[] jugadores;
		private boolean totalJugAceptados=false;
		private boolean totalRondAceptadas=false;
		private boolean cpu= false;
		private String cpu1="CPU1";
		private String cpu2="CPU2";
		private String cpu3="CPU3";
		private String cpu4="CPU4";
		boolean esCorrecta=false;
		
		
		public JuegoDePreguntas() {
			entrada=new Scanner(System.in);
		}
		
		//Implementación de los métodos de la interfaz
		
		public void iniciar() throws FileNotFoundException {
			
			do {
				do {
					System.out.println("");
					System.out.println("¿ERES MÁS LISTO QUE UNA COMPUTADORA?");
					System.out.println("MENÚ PRINCIPAL");
					System.out.println("1. JUGAR PARTIDA");
					System.out.println("2. RANKING");
					System.out.println("3. HISTÓRICO");
					System.out.println("4. JUGADORES");
					System.out.println("5. SALIR");
					System.out.print("INGRESE UNA OPCIÓN: ");
					opcion=entrada.nextInt();
					if (opcion ==1 || opcion ==2 || opcion==3 || opcion==4 || opcion==5) {
						opcionAceptada=true;
					} else {
						System.out.println("OPCIÓN NO VÁLIDA, VUELVE A INTENTARLO.");
						opcionAceptada=false;
					}
				}while (!opcionAceptada);
				
				switch (opcion) {
				case 1:
					jugar();
					break;
				case 2:
					ranking();
					break;
				case 3:
					historico();
					break;
				case 4:
					gestionJugadores();
					break;
				case 5:
					finalizar();
//					System.out.println("HASTA LA PRÓXIMA");
					salir=true;
					break;
				}
			} while(!salir);
			
		}

		
		public void jugar() {
//			int numJugadores=0;
			Jugador [] jugadores= null;	    

			//Información para iniciar la partida
//		
				
			System.out.print("INGRESE EL NÚMERO DE JUGADORES (1-4): ");
			numJugadores= entrada.nextInt();
			System.out.print("INGRESE EL NÚMERO DE RONDAS (3,5,10 Ó 20): ");
			int numRondas=entrada.nextInt();
			do {
				if((numJugadores >=1 && numJugadores <=5) && (numRondas==3 || numRondas==5 || numRondas==10 || numRondas==20) ) {
					totalJugAceptados=true;
					totalRondAceptadas=true;
					jugadores =new Jugador[numJugadores];
				} else {
					System.out.println("ERROR, LOS JUGADORES (ENTRE 1-4) Y LAS RONDAS (ENTRE 3,5,10 Ó 20). VUELVE A INTENTARLO");
					 totalJugAceptados=false;
					 totalRondAceptadas=false;
				}
				
			}while (!totalJugAceptados && !totalRondAceptadas);
			 
			//Crear jugadores y asignarles un nombre

			for (int i=0; i<numJugadores;i++) {
				System.out.print("ESCRIBE EL NOMBRE DEL JUGADOR " + (i+1) + ": ");
				String nombre=entrada.next();
				if (nombre.equalsIgnoreCase(cpu1)|| nombre.equalsIgnoreCase(cpu2) || nombre.equalsIgnoreCase(cpu3) || nombre.equalsIgnoreCase(cpu4) ) {
					jugadores[i]=new Jugador(nombre, 0,true );
				} else {
					jugadores[i]=new Jugador(nombre,0, false );
				}
				
			}
			/*********************REVISAR****************************/
			 // Comenzamos la partida		
//			 Partida partida = new Ronda(jugadores, numRondas);
//			 ((JuegoInterfaz) partida).jugar(); //Creo que no hace falta
			Ronda ronda= new Ronda(jugadores, numRondas); 
			for (int i = 0; i < numRondas; i++) {
			        System.out.println("Ronda " + (i + 1));
			        System.out.println("--------");
			        
			        for (int j = 0; j < jugadores.length; j++) {
//			        	Jugador jugador = jugadores[j];
			            System.out.println("Turno de " + jugadores[j].getNombre());
			            ronda.Pregunta();
//			            Pregunta();
			            
			            // Obtener la respuesta del jugador utilizando el objeto Scanner
			            String respuesta = entrada.nextLine();
			            
			            // Validar y procesar la respuesta
			            
			           ronda.validarRespuesta(respuesta);
//			            validarRespuesta(respuesta);
			           
			           if (jugadores[j].getNombre().equalsIgnoreCase(cpu1) || jugadores[j].getNombre().equalsIgnoreCase(cpu2)||jugadores[j].getNombre().equalsIgnoreCase(cpu3) ||jugadores[j].getNombre().equalsIgnoreCase(cpu4)) {
			        		  if( ronda.tipoPregunta==0) { //Si la pregunta es de mates
			        			  System.out.println("SOY BUENÍSIMOS EN MATEMÁTICAS. SIEMPRE ACIERTO ¨;) ");			        			  
			        		  } else if(ronda.tipoPregunta==1) { //Si la pregunta es de letras
			        			  System.out.println("SOY MUY MALO EN LETRAS. SIEMPRE FALLO :( ");
			        		  } else if(ronda.tipoPregunta==2) { //Si la pregunta es de ingles
			        			  System.out.println("NO SOY BUENO EN INGLÉS, PERO CONFÍO EN MI SUERTE ^_^");
			        			  Random random=new Random();
			        			  int opcionAlAzar=random.nextInt(4)+1; /*Genera un número aleatorio entre 0 y 3, y luego se le suma 1
			        			  para obtener un número entre 1 y 4.*/
			        			  respuesta=String.valueOf(opcionAlAzar); //Convierte el número en String para asignarlo como respuesta 
			        		  }
			        	   } //fin if (jugadores[j]...)
			           else {
			        	   if(esCorrecta==true) {
				        	   System.out.println("RESPUESTA CORRECTA");			        	   
				           	}//fin if(esCorrecta==true) 
				           else {
				        	   System.out.println("ERROR, RESPUESTA INCORRECTA");
				           	}
			        	  }
			           
			            // Resto del código...
			        } // fin for(int j=0...)
			    } //fin for(int i=0...)
			
			
			System.out.println("");
			System.out.println("****RESULTADOS****");
			
			for (int i=0; i<numJugadores; i++) {
//	            System.out.println(jugadores[i].getNombre() + ": " + jugadores[i].getPuntuacion() + " puntos");

	            if (jugadores[i].getNombre().equalsIgnoreCase(cpu1) || jugadores[i].getNombre().equalsIgnoreCase(cpu2)
	            		||jugadores[i].getNombre().equalsIgnoreCase(cpu3) ||jugadores[i].getNombre().equalsIgnoreCase(cpu4)) {
	            	if(i==0 && ronda.tipoPregunta==0) {
	            		contVictoriasJug1=jugadores[i].getPuntuacion();
		            	totalVictoriasJug1+=contVictoriasJug1;
	            	} else if(i==0 && ronda.tipoPregunta==1) {
	            		contVictoriasJug1=contVictoriasJug1;
		            	totalVictoriasJug1+=contVictoriasJug1;
	            	} else if(i==0 && ronda.tipoPregunta==2) {
	            		if(esCorrecta==true) {
	            			System.out.println("ACERTÉ :}");
	            			contVictoriasJug1=jugadores[i].getPuntuacion();
			            	totalVictoriasJug1+=contVictoriasJug1;
	            		} else {
	            			System.out.println("PUES FALLÉ :[ ");
	            			contVictoriasJug1=contVictoriasJug1;
			            	totalVictoriasJug1+=contVictoriasJug1;
	            		}
	            	} //fin if(i==0 && ronda.tipoPregunta==2)
	            	else if(i==1 && ronda.tipoPregunta==0) {
	            		contVictoriasJug2=jugadores[i].getPuntuacion();
		            	totalVictoriasJug2+=contVictoriasJug2;
	            	} else if(i==1 && ronda.tipoPregunta==1) {
	            		contVictoriasJug2=contVictoriasJug2;
		            	totalVictoriasJug2+=contVictoriasJug2;
	            	} else if(i==1 && ronda.tipoPregunta==2) {
	            		if(esCorrecta==true) {
	            			System.out.println("ACERTÉ :}");
	            			contVictoriasJug2=jugadores[i].getPuntuacion();
			            	totalVictoriasJug2+=contVictoriasJug2;
	            		} else {
	            			System.out.println("PUES FALLÉ :[ ");
	            			contVictoriasJug2=contVictoriasJug2;
			            	totalVictoriasJug2+=contVictoriasJug2;
	            		}
	            	} //fin if(i==1 && ronda.tipoPregunta==2)
	            	else if(i==2 && ronda.tipoPregunta==0) {
	            		contVictoriasJug3=jugadores[i].getPuntuacion();
		            	totalVictoriasJug3+=contVictoriasJug3;
	            	} else if(i==2 && ronda.tipoPregunta==1) {
	            		contVictoriasJug3=contVictoriasJug3;
		            	totalVictoriasJug3+=contVictoriasJug3;
	            	} else if(i==2 && ronda.tipoPregunta==2) {
	            		if(esCorrecta==true) {
	            			System.out.println("ACERTÉ :}");
	            			contVictoriasJug3=jugadores[i].getPuntuacion();
			            	totalVictoriasJug3+=contVictoriasJug3;
	            		} else {
	            			System.out.println("PUES FALLÉ :[ ");
	            			contVictoriasJug3=contVictoriasJug3;
			            	totalVictoriasJug3+=contVictoriasJug3;
	            		}
	            	} //fin if(i==3 && ronda.tipoPregunta==2)
	            	else if(i==3 && ronda.tipoPregunta==0) {
	            		contVictoriasJug4=jugadores[i].getPuntuacion();
		            	totalVictoriasJug4+=contVictoriasJug4;
	            	} else if(i==3 && ronda.tipoPregunta==1) {
	            		contVictoriasJug4=contVictoriasJug4;
		            	totalVictoriasJug4+=contVictoriasJug4;
	            	} else if(i==3 && ronda.tipoPregunta==2) {
	            		if(esCorrecta==true) {
	            			System.out.println("ACERTÉ :}");
	            			contVictoriasJug4=jugadores[i].getPuntuacion();
			            	totalVictoriasJug4+=contVictoriasJug4;
	            		} else {
	            			System.out.println("PUES FALLÉ :[ ");
	            			contVictoriasJug4=contVictoriasJug4;
			            	totalVictoriasJug4+=contVictoriasJug4;
	            		}
	            	} //fin if(i==0 && ronda.tipoPregunta==2)
	            }//fin if(jugadores[i]...)
	            
	            if (i==0) {
	            	contVictoriasJug1=jugadores[i].getPuntuacion();
	            	totalVictoriasJug1+=contVictoriasJug1;
	            }else if (i==1) {
	            	contVictoriasJug2=jugadores[i].getPuntuacion();
	            	totalVictoriasJug2+=contVictoriasJug2;
	            }else if (i==2) {
	            	contVictoriasJug3=jugadores[i].getPuntuacion();
	            	totalVictoriasJug3+=contVictoriasJug3;
	            } else if (i==3) {
	            	contVictoriasJug4=jugadores[i].getPuntuacion();
	            	totalVictoriasJug4+=contVictoriasJug4;
	            }
	            System.out.println(jugadores[i].getNombre() + ": " + jugadores[i].getPuntuacion() + " puntos");
			}
			/*********************REVISAR****************************/
		}
		
		public void ranking() {
			// TODO Auto-generated method stub
			
		}
		
		public void historico() {
			// TODO Auto-generated method stub
			
		}
		
		
		public void gestionJugadores() throws FileNotFoundException {
			int opcion;
			boolean salirGestionJugadores=false;
			//Array de jugadores
			Jugador [] jugadores= new Jugador[4];
//			int numJugadores=0;
			
			
			
			do {
				System.out.println("");
				System.out.println("GESTIÓN DE JUGADORES");
				System.out.println("1. VER JUGADORES");
				System.out.println("2. AÑADIR JUGADOR");
				System.out.println("3. ELIMINAR JUGADOR");
				System.out.println("4. VOLVER AL MENÚ PRINCIPAL");
				System.out.print("INGRESE UNA OPCIÓN: ");
				opcion=entrada.nextInt();
				
				switch (opcion) {
				case 1:
					mostrarJugadores();
					break;
				case 2:
					try {
						añadirJugador();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}
					break;
				case 3:
					try {
						eliminarJugador();
					} catch (IOException e) {
						// TODO Auto-generated catch block
//						e.printStackTrace();
					}
					break;
				case 4:
					System.out.println("VOLVIENDO AL MENÚ PRINCIPAL...");
					salirGestionJugadores=true;
					break;
				}
			} while ( !salirGestionJugadores);
		}

		/*******************************Métodos que usamos en gestionJugadores()*******************************/
		private void mostrarJugadores() throws FileNotFoundException {
			File fichero= new File("src/proyectoFinal2/jugadores.txt");
			Scanner entrada= new Scanner(fichero);
			System.out.println("");
			System.out.println("JUGADORES ACTUALES: ");
//			int contador=1; 
			
			while (entrada.hasNext()) {
				String linea = entrada.nextLine();//La variable línea contiene una linea del fichero SIN EL CARÁCTER SALTO (\n)
				System.out.println("JUGADOR REGISTRADO: " + linea);
//				contador++;
			}
			entrada.close();
		}
		
		private void añadirJugador() throws IOException, Exception{
			File fichero= new File("src/proyectoFinal2/jugadores.txt");
			FileWriter writer= new FileWriter(fichero, true);
			Scanner entrada=new Scanner(fichero);
			
			//Verificar si hay jugadores existente en el fichero
			if (entrada.hasNext()) {
				System.out.println();
				System.out.println("JUGADORES ACTUALES: ");
				while (entrada.hasNext()) {
					String jugadorExistente=entrada.nextLine();
					System.out.println(jugadorExistente);
				}
				System.out.println();
			}
			entrada.close(); //Cerramos el Scanner antes de volver a abrirlo
			
			entrada= new Scanner(System.in);
			
			//Verificar si el nombre del nuevo jugador ya existe
			boolean nombreExistente=false;
			boolean esCpu=false;
			do {
				System.out.print("INGRESE EL NOMBRE DEL NUEVO JUGADOR: ");
				String nombre=entrada.next();
				entrada= new Scanner(fichero); //Abrimos de nuevo el Scanner para leer los jugadores existentes
				while(entrada.hasNext()) {
					String jugadorExistente=entrada.nextLine();
					if (jugadorExistente.equalsIgnoreCase(nombre)) {
						nombreExistente=true;
					}
				}
				
				if (nombreExistente==true) {
					System.out.println("ERROR, EL NOMBRE DE ESTE JUGADOR YA EXISTE.");
				}
				
				else if (nombre.equalsIgnoreCase(cpu1)|| nombre.equalsIgnoreCase(cpu2) || nombre.equalsIgnoreCase(cpu3) || nombre.equalsIgnoreCase(cpu4) ) {
					esCpu= true;
					System.out.println("ERROR, NO SE PUEDEN AÑADIR CPUs.");
				} else {
					System.out.println("JUGADOR AGREGADO EXITOSAMENTE");
					//Escribimos el nuevo jugador al fichero
					writer.write(nombre + "\n");
					writer.close();
				}
				
			}while(nombreExistente==true || esCpu==true);
			
		}

		private void eliminarJugador() throws IOException {
			File fichero = new File("src/proyectoFinal2/jugadores.txt");
		    FileWriter writer = new FileWriter(fichero, true);
		    Scanner entrada = new Scanner(fichero);
		    File ficheroTemporal = new File("src/proyectoFinal2/jugadores_temp.txt");
            FileWriter writerTemporal = new FileWriter(ficheroTemporal, true);
            Scanner teclado = new Scanner(System.in);
            
		    // Verificar si hay jugadores existentes en el fichero
		    if (entrada.hasNext()) {
		    	System.out.println();
		        System.out.println("JUGADORES ACTUALES: ");
		        while (entrada.hasNext()) {
		            String jugadorExistente = entrada.nextLine();
		            System.out.println(jugadorExistente);
		        }
		        System.out.println();
		    }
		    entrada.close(); // Cerramos el Scanner antes de volver a abrirlo

		    

		    // Solicitar al usuario que ingrese el nombre del jugador que quiera eliminar
		    boolean esCpu = false;
		    boolean encontrado = false; // Variable para verificar si se encuentra el jugador
		    do {
		        System.out.print("PON EL NOMBRE DEL JUGADOR QUE QUIERAS ELIMINAR: ");
		        String nombre = teclado.next();
		        entrada = new Scanner(fichero); // Abrimos de nuevo el Scanner para leer los jugadores existentes
//
//	            // Recorrer los jugadores y copiarlos en el fichero temporal sin el nombre del jugador a eliminar
	            while (entrada.hasNext()) {
	                String jugadorExistente = entrada.nextLine();
	                if (!jugadorExistente.equalsIgnoreCase(nombre)) {
	                    writerTemporal.write(jugadorExistente + "\n");
	                } else {
	                    encontrado = true; // El jugador se encontró en el archivo
	                }
	            }
	            
	            if(encontrado==false) {
	            	System.out.println("EL JUGADOR NO EXISTE, NO SE PUEDE ELIMINAR");
	                encontrado = false;
	            }
	            else if (nombre.equalsIgnoreCase(cpu1) || nombre.equalsIgnoreCase(cpu2)
		                || nombre.equalsIgnoreCase(cpu3) || nombre.equalsIgnoreCase(cpu4)) {
		            esCpu = true;
		            System.out.println("ERROR, NO SE PUEDEN PONER CPUs.");
		        } else {
		            // Creamos un fichero temporal para guardar los jugadores sin el jugador a eliminar
//		            File ficheroTemporal = new File("src/proyectoFinal2/jugadores_temp.txt");
//		            FileWriter writerTemporal = new FileWriter(ficheroTemporal);

//		            entrada = new Scanner(fichero); // Abrimos de nuevo el Scanner para leer los jugadores existentes
//
//		            // Recorrer los jugadores y copiarlos en el fichero temporal sin el nombre del jugador a eliminar
//		            while (entrada.hasNext()) {
//		                String jugadorExistente = entrada.nextLine();
//		                if (!jugadorExistente.equalsIgnoreCase(nombre)) {
//		                    writerTemporal.write(jugadorExistente + "\n");
//		                } else {
//		                    encontrado = true; // El jugador se encontró en el archivo
//		                }
//		            }
		            // cerramos los ficheros y eliminamos el fichero original
		            entrada.close();
		            writer.close();
		            fichero.delete();

		            // cerramos el fichero temporal
		            writerTemporal.close();

		            // Renombramos el fichero temporal con el nombre del fichero original
		            ficheroTemporal.renameTo(fichero);

//		            if (encontrado) {
		                System.out.println("JUGADOR ELIMINADO EXITOSAMENTE");
		                esCpu = false;
		                encontrado=true;
//		            } 
//		            else {
//		                System.out.println("EL JUGADOR NO EXISTE, NO SE PUEDE ELIMINAR");
//		                encontrado = false;
//		            }
		        } // fin del else
		    } while (esCpu==true);

		}
		
		/*******************************Hasta aquí los Métodos que usamos en gestionJugadores()*******************************/
		public void finalizar() {
			// TODO Auto-generated method stub
			System.out.println("HASTA LA PRÓXIMA");
		}

}	