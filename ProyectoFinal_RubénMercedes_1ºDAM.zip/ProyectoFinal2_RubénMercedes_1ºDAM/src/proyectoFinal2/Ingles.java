package proyectoFinal2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Ingles {

	//obtenemos la pregunta
	private ArrayList<String[]> obtenerPreguntasEnIngles() {
		ArrayList<String[]> preguntas=new ArrayList<>();
		
	    try (BufferedReader br = new BufferedReader(new FileReader("src/proyectoFinal2/ingles.txt"))) {
	    	String pregunta;
	    	while ((pregunta = br.readLine()) !=null) {
	    		String opciones []= new String [4];
	    		
	    		for (int i=0; i<4; i++) {
	    			opciones[i]=br.readLine();
	    		}
	    		preguntas.add(opciones);
	    	}
	    } 
	    catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return preguntas;
	}
	
	
	//Generamos la pregunta
	public String generaPregunta() {
		ArrayList<String[]> preguntas= obtenerPreguntasEnIngles();
		Random random=new Random();
		int indice=random.nextInt(preguntas.size());
		String opciones []=preguntas.get(indice);
		
		StringBuilder pregunta= new StringBuilder();
		pregunta.append(opciones[0]).append("\n");
        ArrayList<String> opcionesAleatorias = new ArrayList<>(Arrays.asList(opciones).subList(1, 4));
        opcionesAleatorias.add(opciones[1]);
        opcionesAleatorias.sort((a, b) -> random.nextInt(3) - 1);
        
        char letra='A';
        for (int i = 0; i < opcionesAleatorias.size(); i++) {
        	String opcion = opcionesAleatorias.get(i);
            pregunta.append((char) (letra + i)).append(") ").append(opcion).append("\n");
        }
        
        return pregunta.toString();
	}
	
	//Método para validar la respuesta
	public boolean validarRespuesta(String pregunta, String respuesta) {
		
		//Hay que obtener la opción correcta de la pregunta generada previamente
		String opcionCorrecta=pregunta.substring(0, pregunta.indexOf("\n"));
		
		//Extraemos las opciones de la pregunta
		ArrayList<String>opciones= new ArrayList<>(Arrays.asList(pregunta.split("\n")));
		
		//Obtener la letra correspondiente a la opción correcta
		char letraCorrecta=opcionCorrecta.charAt(0);
		
		//Convertir la respuesta proporcionada a letra
		char respuestaLetra=respuesta.toUpperCase().charAt(0);
		
		//Validar si la respuesta es correcta
		return respuestaLetra == letraCorrecta;
	}
	
	
}
