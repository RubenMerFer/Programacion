package proyectoFinal2;

import java.io.FileNotFoundException;

public class ProgramaPrincipalJuego {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		JuegoDePreguntas juego= new JuegoDePreguntas();
		juego.iniciar();

	}

}

